#include "count.h"

Count gCount;
